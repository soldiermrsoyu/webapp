# replit.md

## Overview

This is a Node.js web application for managing FCU (Fan Coil Unit) maintenance tasks. The system serves two user roles: **SPV (Supervisors)** who manage and assign tasks, and **Teknisi (Technicians)** who execute maintenance work. The application provides role-based dashboards and task management functionality.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Framework
- **Express.js** serves as the web framework, handling routing, middleware, and HTTP requests
- Server runs on port 5000 with EJS as the templating engine for server-side rendering

### Authentication & Authorization
- **Session-based authentication** using `express-session` with session secret stored in environment variables
- **Role-based access control** implemented through two middleware functions:
  - `auth.js`: Validates user is logged in (redirects to /login if not)
  - `role.js`: Factory function that checks if user has required role (returns 403 if not)
- Passwords are stored in plain text (security improvement needed)

### Routing Structure
- `/` and `/login` - Authentication routes
- `/dashboard` - Role-based redirect hub
- `/spv` and `/spv/task` - Supervisor views (protected by 'spv' role)
- `/teknisi` and `/teknisi/task` - Technician views (protected by 'teknisi' role)
- `/api/*` - JSON API endpoints for data operations

### Frontend Architecture
- **Server-side rendering** with EJS templates located in `views/` directory
- Static assets (CSS, JS) served from `public/` directory
- Responsive design with mobile-first approach (bottom nav padding in CSS)

### Database Schema (Inferred)
Two main tables identified:
1. **users**: `id`, `user` (username), `password`, `role` ('spv' or 'teknisi')
2. **jadwal**: `id`, `lantai` (floor), `unit`, `tanggal` (date), `alias` - FCU scheduling data

## External Dependencies

### Database
- **PostgreSQL** via Supabase - Connection uses `pg` library with SSL enabled
- Connection string configured through `DATABASE_URL` environment variable

### Environment Variables Required
- `DATABASE_URL` - PostgreSQL connection string (Supabase)
- `SESSION_SECRET` - Secret key for session encryption

### NPM Packages
- `express` - Web framework
- `ejs` - Template engine
- `express-session` - Session management
- `pg` - PostgreSQL client
- `dotenv` - Environment variable loading